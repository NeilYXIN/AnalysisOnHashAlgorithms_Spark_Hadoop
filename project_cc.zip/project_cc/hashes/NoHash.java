public class NoHash { 
    public static int noHash(byte[] bytes) {
        return 0;
    }
}
